// SPDX-License-Identifier: Apache-2.0

use super::super::{NmSettingVeth, ToKeyfile};

impl ToKeyfile for NmSettingVeth {}
