// SPDX-License-Identifier: Apache-2.0

use super::super::{NmSettingMacVlan, ToKeyfile};

impl ToKeyfile for NmSettingMacVlan {}
