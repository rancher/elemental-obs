// SPDX-License-Identifier: Apache-2.0

use super::super::{NmSettingEthtool, ToKeyfile};

impl ToKeyfile for NmSettingEthtool {}
